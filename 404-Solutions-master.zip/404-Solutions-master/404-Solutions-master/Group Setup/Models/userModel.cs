﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Group_Setup.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace Group_Setup.Models
{
    public class UserModel
    {
        
        public string Number { get; set; }

        

    }
}
